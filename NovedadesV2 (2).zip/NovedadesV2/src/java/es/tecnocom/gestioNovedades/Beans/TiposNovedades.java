/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package es.tecnocom.gestioNovedades.Beans;

/**
 *
 * @author T14750
 */
public class TiposNovedades {
   private int codTipoNovedad;
   private String nombreNovedad;

    public TiposNovedades() {
    }

    public TiposNovedades(int codTipoNovedad, String nombreNovedad) {
        this.codTipoNovedad = codTipoNovedad;
        this.nombreNovedad = nombreNovedad;
    }

    public int getCodTipoNovedad() {
        return codTipoNovedad;
    }

    public void setCodTipoNovedad(int codTipoNovedad) {
        this.codTipoNovedad = codTipoNovedad;
    }

    public String getNombreNovedad() {
        return nombreNovedad;
    }

    public void setNombreNovedad(String nombreNovedad) {
        this.nombreNovedad = nombreNovedad;
    }
   
}
