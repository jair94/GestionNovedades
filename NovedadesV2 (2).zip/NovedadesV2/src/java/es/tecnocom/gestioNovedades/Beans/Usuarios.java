/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package es.tecnocom.gestioNovedades.Beans;

/**
 *
 * @author T14750
 */
public class Usuarios {
    private String TUsuario;
    private String nombreUser;
    private String apellidoUser;
    private String correo;
    private int numTel;
    private int numDoc;
    private int tipoDoc;
    private int codApli;

    public Usuarios() {
    }

    public Usuarios(String TUsuario, String nombreUser, String apellidoUser, String correo, int numTel, int numDoc) {
        this.TUsuario = TUsuario;
        this.nombreUser = nombreUser;
        this.apellidoUser = apellidoUser;
        this.correo = correo;
        this.numTel = numTel;
        this.numDoc = numDoc;
    }

    
    public String getTUsuario() {
        return TUsuario;
    }

    public void setTUsuario(String TUsuario) {
        this.TUsuario = TUsuario;
    }

    public String getNombreUser() {
        return nombreUser;
    }

    public void setNombreUser(String nombreUser) {
        this.nombreUser = nombreUser;
    }

    public String getApellidoUser() {
        return apellidoUser;
    }

    public void setApellidoUser(String apellidoUser) {
        this.apellidoUser = apellidoUser;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public int getNumTel() {
        return numTel;
    }

    public void setNumTel(int numTel) {
        this.numTel = numTel;
    }

    public int getNumDoc() {
        return numDoc;
    }

    public void setNumDoc(int numDoc) {
        this.numDoc = numDoc;
    }

    public int getTipoDoc() {
        return tipoDoc;
    }

    public void setTipoDoc(int tipoDoc) {
        this.tipoDoc = tipoDoc;
    }

    public int getCodApli() {
        return codApli;
    }

    public void setCodApli(int codApli) {
        this.codApli = codApli;
    }
    
    
}
