/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package es.tecnocom.gestioNovedades.Beans;

/**
 *
 * @author T14750
 */
public class RegistroSAP {
    private int codValidacionSAP;
    private String opcionesValidacionSAP;

    public RegistroSAP() {
    }

    public RegistroSAP(int codValidacionSAP, String opcionesValidacionSAP) {
        this.codValidacionSAP = codValidacionSAP;
        this.opcionesValidacionSAP = opcionesValidacionSAP;
    }

    public int getCodValidacionSAP() {
        return codValidacionSAP;
    }

    public void setCodValidacionSAP(int codValidacionSAP) {
        this.codValidacionSAP = codValidacionSAP;
    }

    public String getOpcionesValidacionSAP() {
        return opcionesValidacionSAP;
    }

    public void setOpcionesValidacionSAP(String opcionesValidacionSAP) {
        this.opcionesValidacionSAP = opcionesValidacionSAP;
    } 
    
}
