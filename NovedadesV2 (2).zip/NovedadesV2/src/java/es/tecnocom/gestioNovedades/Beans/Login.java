/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package es.tecnocom.gestioNovedades.Beans;

import org.apache.commons.codec.digest.DigestUtils;

/**
 *
 * @author T14750
 */
public class Login {
    private String user;
    private String pwd;

    public Login() {
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }
    
    public String Encrip (){
      String txtEncriptPWD= DigestUtils.md5Hex(pwd);
      String txtEncriptadoCon= DigestUtils.sha1Hex(txtEncriptPWD);
         System.out.println(txtEncriptadoCon);
         return txtEncriptadoCon;
    }
    
    
}
