/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package es.tecnocom.gestionNovedades.Modelo;

import static es.tecnocom.gestionNovedades.Modelo.Conexion.conexion;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author T14750
 */
public class Consultas extends Conexion {

    private String user = "";

    public boolean Autenticacion(String TUsuario, String pwd) throws SQLException {
        Statement st = conexion().createStatement();
        ResultSet rs = null;
        String consulta = "Select * from login";
        rs = st.executeQuery(consulta);

        while (rs.next()) {
            if ((TUsuario.equals(rs.getString("TUsuarios")) && pwd.equals(rs.getString("Pwd")))) {
                return true;
            }
        }
        return false;
    }

    public boolean RepContraseña(String UT, String DI) throws SQLException {
        Statement st = conexion().createStatement();
        ResultSet rs = null;
        String consulta = "SELECT TUsuarios, NumDocUsuario FROM usuarios;";
        rs = st.executeQuery(consulta);

        while (rs.next()) {
            if ((UT.equals(rs.getString("TUsuarios")) && DI.equals(rs.getString("NumDocUsuario")))) {
                this.user = UT;
                return true;
            }
        }
        return false;
    }

    public void actualizarPWS(String pws) throws SQLException {
        Statement st = conexion().createStatement();
        ResultSet rs = null;
        String consulta = "UPDATE Pwd\n"
                + "SET \n"
                + "   Pwd =" + pws + "WHERE\n" + "TUsuarios =" + user;
        rs = st.executeQuery(consulta);

    }
    /**
     *
     * @param args
     */
//    public static void main (String[] args) throws SQLException {
//      Consultas con = new Consultas();
//       System.out.println(con.RepContraseña("T14750","987654321"));
//        //System.out.println(con.Autenticacion("", ""));
//   }
}
