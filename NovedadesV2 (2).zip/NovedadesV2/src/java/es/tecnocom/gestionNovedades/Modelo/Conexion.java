/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package es.tecnocom.gestionNovedades.Modelo;

import java.sql.*;

/**
 *
 * @author T14750
 */
public class Conexion {
   static  Connection con = null;
     
     public static Connection conexion() throws SQLException{
         try {
             //Cargar Drive de conexion
             Class.forName("com.mysql.jdbc.Driver");
             con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gestionnovedades", "root", "1234");
         }catch(Exception e){
             con = null;
         }finally{
             return con;
             
         }
        
     }

     //Metodo utilizado para cerrar el callablestatemente
     public static synchronized void cerrarCall(CallableStatement cl){
         try{
             cl.close();            
         }catch(Exception e){
         }
     }
     //Metodo utilizado para cerrar el resulset  de datos
     public static synchronized void cerrarConexion(ResultSet rs){
         try{rs.close();}catch(Exception e){}
     }
     //Metodo Utilizado para cerrar la conexión
     public static synchronized void cerrarConexion(Connection cn){
         try{cn.close();}catch(Exception e){}
     }
     //Metodo utilizado para dezacer los cambios en la base de datos
     public static synchronized void deshacerCambios(Connection cn){
         try{cn.rollback();}catch(Exception e){}
     }

}
