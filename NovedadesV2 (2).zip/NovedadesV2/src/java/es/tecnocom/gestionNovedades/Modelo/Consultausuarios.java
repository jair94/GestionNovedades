/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package es.tecnocom.gestionNovedades.Modelo;

import es.tecnocom.gestioNovedades.Beans.Usuarios;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;

/**
 *
 * @author T14750
 */
public class Consultausuarios extends Conexion{
    
    public static LinkedList<Usuarios> getUsuarios()  throws SQLException{
        LinkedList<Usuarios> listaUsuarios = new LinkedList<Usuarios>();
        try {
        Statement st = conexion().createStatement();
        ResultSet rs = null;
        String consulta = "Select * from usuarios";
        rs = st.executeQuery(consulta);
        while(rs.next()){
            Usuarios usuarios = new Usuarios();
            usuarios.setTUsuario(rs.getString("TUsuarios"));
            usuarios.setNombreUser(rs.getString("NomUsuario"));
            usuarios.setApellidoUser(rs.getString("ApellidosUsuario"));
            listaUsuarios.add(usuarios);
        }
        rs.close();
        st.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
            
        return listaUsuarios;
        
    }
}
