/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package es.tecnocom.gestionNovedades.Modelo;

import es.tecnocom.gestioNovedades.Beans.TiposNovedades;
import static es.tecnocom.gestionNovedades.Modelo.Conexion.conexion;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;

/**
 *
 * @author T14750
 */
public class ConsultaTipoNovedad extends Conexion{
      public static LinkedList<TiposNovedades> getTipoNovedades()  throws SQLException{
        LinkedList<TiposNovedades> listaTipoNovedades = new LinkedList<TiposNovedades>();
        try {
        Statement st = conexion().createStatement();
        ResultSet rs = null;
        String consulta = "Select * from tiponovedades";
        rs = st.executeQuery(consulta);
        while(rs.next()){
            TiposNovedades tipoNovedades = new TiposNovedades();
            tipoNovedades.setCodTipoNovedad(rs.getInt("CodTipoNovedad"));
            tipoNovedades.setNombreNovedad(rs.getString("NombreNovedad"));
            listaTipoNovedades.add(tipoNovedades);
        }
        rs.close();
        st.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
            
        return listaTipoNovedades;
        
    }
}
